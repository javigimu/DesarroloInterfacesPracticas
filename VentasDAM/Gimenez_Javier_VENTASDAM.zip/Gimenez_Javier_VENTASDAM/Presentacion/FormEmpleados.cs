﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using TextBox = System.Windows.Forms.TextBox;
using ToolTip = System.Windows.Forms.ToolTip;

namespace Presentacion
{
    /// <summary>
    /// <autor>Javier Gimenez</autor>
    /// </summary>
    public partial class FormEmpleados : Form
    {
        bool primeraActivacionForm;
        char opcionInsertarOModificar;
        bool tituloCortesiaValidado;
        bool nombreValidado;
        bool apellidoValidado;
        bool direccionValidada;
        bool ciudadValidada;
        bool regionValidada;
        bool codigoPostalValidado;
        bool paisValidado;
        bool telefonoValidado;
        bool extensionValidada;
        bool tituloValidado;
        bool fotoPathValidado;
        bool fotoValidada;
        bool anotacionesValidado;
        bool fechaNacimientoValidada;
        bool fechaContratacionValidada;

        byte[]? fotoNuevoEmpleado;

        public FormEmpleados()
        {
            InitializeComponent();
        }

        public FormEmpleados(char opcion) : this()
        {
            primeraActivacionForm = true;
            opcionInsertarOModificar = opcion;
            tituloCortesiaValidado = true;
            nombreValidado = false;
            apellidoValidado = false;
            direccionValidada = true;
            ciudadValidada = true;
            regionValidada = true;
            codigoPostalValidado = true;
            paisValidado = true;
            extensionValidada = true;
            extensionValidada = true;
            tituloValidado = true;
            fotoPathValidado = true;
            fotoValidada = true;
            anotacionesValidado = true;
            fechaNacimientoValidada = true;
            fechaContratacionValidada = true;

            fotoNuevoEmpleado = null;
        }

        private void FormEmpleados_Load(object sender, EventArgs e)
        {
            ConfigurarFormatoFechasInicial();
            if (opcionInsertarOModificar == 'i')
                btAceptar.Text = "Insertar";
            else if (opcionInsertarOModificar == 'm')
            {
                btAceptar.Text = "Modificar";
                MostrarFormBuscarEmpleado();
            }
        }

        // Configura el formato inicial de las fechas para permitir que el usuario no seleccione ninguna fecha
        private void ConfigurarFormatoFechasInicial()
        {
            dtpFechaNacimiento.Format = DateTimePickerFormat.Custom;
            dtpFechaNacimiento.CustomFormat = " ";
            dtpFechaContratacion.Format = DateTimePickerFormat.Custom;
            dtpFechaContratacion.CustomFormat = " ";
        }

        // cambia el formato de la fecha una vez que el usuario seleccione una
        private void CambiarFormatoFecha(object sender, EventArgs e)
        {
            string dtpName = ((DateTimePicker)sender).Name;
            if (dtpName == "dtpFechaNacimiento")
            {
                dtpFechaNacimiento.CustomFormat = "yyyy/MM/dd";
                ValidarFechaNacimiento();
            }
            else if (dtpName == "dtpFechaContratacion")
            { 
                dtpFechaContratacion.CustomFormat = "yyyy/MM/dd";
                ValidarFechaContratacion();
            }            
        }             

        private void AbrirBusquedaFichero(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Selecciona una imagen para el empleado";
            openFileDialog1.Filter = "Imagenes (*.jpg; *.jpeg; *.png; *.tif; *.gif)|*.jpg;*.jpeg;*.png;*.tif;*.gif";

            if (openFileDialog1.ShowDialog() == DialogResult.OK &&
                File.Exists(openFileDialog1.FileName))
            {
                tbFoto.Text = openFileDialog1.FileName;
            }
        }

        private void MostrarFormPrincipal()
        {
            Owner.Show();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            MostrarFormPrincipal();
            Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (opcionInsertarOModificar == 'i')
                MessageBox.Show("Insertar");
            else if (opcionInsertarOModificar == 'm')
                MessageBox.Show("Modificar");
        }

        private void MostrarFormBuscarEmpleado()
        {
            FormBusqueda formBuscarEmpleado = new FormBusqueda();
            formBuscarEmpleado.Owner = this;
            this.Hide();
            formBuscarEmpleado.ShowDialog();
        }

        private void FormEmpleados_FormClosing(object sender, FormClosingEventArgs e)
        {
            MostrarFormPrincipal();
        }

        #region "validaciones"

        private void ValidarTituloCortesia(object sender, EventArgs e)
        {
            tituloCortesiaValidado = MarcarCampoOk(cbTituloCortesia);
        }

        /// <summary>
        /// Validación de un campo textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ValidarCampo(object sender, EventArgs e)
        {
            // compruebo si se acaba de activar el formulario para que no marque casillas en rojo sin intervención del usuario
            if (primeraActivacionForm)
            {
                primeraActivacionForm = false;
            }
            else
            {
                string error = "";
                int resultado = 0;

                // Validación de los campos TextBox
                TextBox? tbSender = sender as TextBox;
                switch (tbSender?.Name)
                {
                    case "tbNombre":                    
                        resultado = Validaciones.ValidarCadena(tbNombre.Text, 10, false);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Nombre no permite más de 10 carácteres" + Environment.NewLine;
                                    break;
                                case 2:
                                    error = "El campo Nombre no puede estar vacío" + Environment.NewLine;
                                    break;
                            }
                            nombreValidado = MarcarError(tbNombre, error);
                        }
                        else
                            nombreValidado = MarcarCampoOk(tbNombre);

                        break;                    

                    case "tbApellido":                    
                        resultado = Validaciones.ValidarCadena(tbApellido.Text, 20, false);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Apellido no permite más de 20 carácteres" + Environment.NewLine;
                                    break;
                                case 2:
                                    error = "El campo Apellido no puede estar vacío" + Environment.NewLine;
                                    break;
                            }
                            apellidoValidado = MarcarError(tbApellido, error);
                        }
                        else
                            apellidoValidado = MarcarCampoOk(tbApellido);

                        break;                    
                
                    case "tbDireccion":                    
                        resultado = Validaciones.ValidarCadena(tbDireccion.Text, 60, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Dirección no permite más de 60 carácteres" + Environment.NewLine;
                                    break;
                            }
                            direccionValidada = MarcarError(tbDireccion, error);
                        }
                        else
                            direccionValidada = MarcarCampoOk(tbDireccion);

                        break;                    

                    case "tbCiudad":                    
                        resultado = Validaciones.ValidarCadena(tbCiudad.Text, 15, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Ciudad no permite más de 15 carácteres" + Environment.NewLine;
                                    break;
                            }
                            ciudadValidada = MarcarError(tbCiudad, error);
                        }
                        else
                            ciudadValidada = MarcarCampoOk(tbCiudad);

                        break;                    

                    case "tbRegion":                    
                        resultado = Validaciones.ValidarCadena(tbRegion.Text, 15, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Region no permite más de 15 carácteres" + Environment.NewLine;
                                    break;
                            }
                            regionValidada = MarcarError(tbRegion, error);
                        }
                        else
                            regionValidada = MarcarCampoOk(tbRegion);

                        break;                    

                    case "tbCodigoPostal":                    
                        resultado = Validaciones.ValidarCadena(tbCodigoPostal.Text, 10, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Codigo Postal no permite más de 10 carácteres" + Environment.NewLine;
                                    break;
                            }
                            codigoPostalValidado = MarcarError(tbCodigoPostal, error);
                        }
                        else
                            codigoPostalValidado = MarcarCampoOk(tbCodigoPostal);

                        break;                    

                    case "tbPais":                    
                        resultado = Validaciones.ValidarCadena(tbPais.Text, 15, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Pais no permite más de 15 carácteres" + Environment.NewLine;
                                    break;
                            }
                            paisValidado = MarcarError(tbPais, error);
                        }
                        else
                            paisValidado = MarcarCampoOk(tbPais);

                        break;                                          

                    case "tbExtension":                    
                        resultado = Validaciones.ValidarCadena(tbExtension.Text, 4, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Extension no permite más de 4 carácteres" + Environment.NewLine;
                                    break;
                            }
                            extensionValidada = MarcarError(tbExtension, error);
                        }
                        else
                            extensionValidada = MarcarCampoOk(tbExtension);

                        break;

                    case "tbTitulo":
                        resultado = Validaciones.ValidarCadena(tbTitulo.Text, 30, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Título no permite más de 30 carácteres" + Environment.NewLine;
                                    break;
                            }
                            tituloValidado = MarcarError(tbTitulo, error);
                        }
                        else
                            tituloValidado = MarcarCampoOk(tbTitulo);

                        break;

                    case "tbFotoPath": // TODO validar URL bien formada
                        resultado = Validaciones.ValidarCadena(tbFotoPath.Text, 255, true);
                        if (resultado > 0)
                        {
                            switch (resultado)
                            {
                                case 1:
                                    error = "El campo Foto Path no permite más de 255 carácteres" + Environment.NewLine;
                                    break;
                            }
                            fotoPathValidado = MarcarError(tbFotoPath, error);
                        }
                        else
                            fotoPathValidado = MarcarCampoOk(tbFotoPath);

                        break;

                    case "tbFoto":
                        if (tbFoto.Text.Length > 0)
                        {
                            fotoValidada = MarcarCampoOk(tbFoto);
                            fotoNuevoEmpleado = File.ReadAllBytes(tbFoto.Text);
                        }

                        break;

                    case "tbAnotaciones":                       
                        if (tbAnotaciones.Text.Length > 0)                        
                            anotacionesValidado = MarcarCampoOk(tbAnotaciones);

                        break;

                    case "tbEmpleadoSupervisor":

                        break;
                }
            }
        }

        /// <summary>
        /// método para validar que el teléfono tenga un mínimo de 9 caracteres
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ValidarTelefono(object sender, EventArgs e)
        {
            int resultado = Validaciones.ValidarTelefono(mtbTelefono.Text, 9);
            string error = "";

            if (resultado > 0)
            {
                switch (resultado)
                {
                    case 1:
                        error = "El campo Teléfono debe tener al menos 9 caracteres" + Environment.NewLine;
                        break;
                }
                telefonoValidado = MarcarError(mtbTelefono, error);
            }
            else
                telefonoValidado = MarcarCampoOk(mtbTelefono);
        }

        private void ValidarTelefonoKeyUp(object sender, KeyEventArgs e)
        {
            ValidarTelefono(sender, e);
        }

        /// <summary>
        /// Valida el telefono tomando sus input rejected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ValidarInputRejectedTelefono(object sender, MaskInputRejectedEventArgs e)
        {
            if (mtbTelefono.MaskFull)
            {
                telefonoValidado = MarcarCampoOk(mtbTelefono);
            }
            else if (mtbTelefono.TextLength >= 9)
            {
                telefonoValidado = MarcarCampoOk(mtbTelefono);
            }           
        }

        /// <summary>
        /// Validar que la fecha de nacimiento sea anterior a la fecha actual
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        private void ValidarFechaNacimiento()
        {
            string error = "";
            int resultado = Validaciones.ValidarFechaNacimiento(dtpFechaNacimiento);

            if (resultado > 0)
            {
                switch (resultado)
                {
                    case 1:
                        error = "El campo Fecha Nacimiento debe ser inferior a la fecha actual" + Environment.NewLine;
                        break;
                }
                fechaNacimientoValidada = MarcarError(dtpFechaNacimiento, error);
            }
            else
                fechaNacimientoValidada = MarcarCampoOk(dtpFechaNacimiento);
        }

        /// <summary>
        /// Marca la validacion correcta de la fecha de contratación, ya que no tiene filtros
        /// </summary>
        private void ValidarFechaContratacion()
        {
            fechaContratacionValidada = MarcarCampoOk(dtpFechaContratacion);
        }

        /// <summary>
        /// Marca la casilla en rojo y muestra un tip con la información del error
        /// </summary>
        /// <param name="tb">textbox validado</param>
        /// <param name="error">texto informativo del error</param>
        /// <returns>false para indicar que el campo no está validado correctamente</returns>
        private bool MarcarError(TextBox tb, string error)
        {
            ToolTip TTIP = new ToolTip();
            tb.BackColor = Color.LightCoral;
            TTIP.SetToolTip(tb, error);
            errorProvider1.SetError(tb, error);
            return false;
        }

        /// <summary>
        /// Marca error en un masked text box
        /// </summary>
        /// <param name="tb"></param>
        /// <param name="error"></param>
        /// <returns></returns>
        private bool MarcarError(MaskedTextBox tb, string error)
        {
            ToolTip TTIP = new ToolTip();
            tb.BackColor = Color.LightCoral;
            TTIP.SetToolTip(tb, error);
            errorProvider1.SetError(tb, error);
            return false;
        }

        /// <summary>
        /// Marca error en un campo DateTimePicker
        /// </summary>
        /// <param name="dtp"></param>
        /// <param name="error"></param>
        /// <returns></returns>
        private bool MarcarError(DateTimePicker dtp, string error)
        {
            ToolTip TTIP = new ToolTip();
            dtp.BackColor = Color.LightCoral;
            TTIP.SetToolTip(dtp, error);
            errorProvider1.SetError(dtp, error);
            dtp.ShowCheckBox = false;
            return false;
        }

        private bool MarcarCampoOk(System.Windows.Forms.ComboBox cb)
        {
            cb.BackColor = Color.LightGreen;
            return true;
        }

        /// <summary>
        /// Marca la casilla en verde para visualizar que la validación es correcta
        /// </summary>
        /// <param name="tb">textbox validado</param>
        /// <returns>true para indicar que el campo está validado correctamente</returns>
        private bool MarcarCampoOk(TextBox tb)
        {
            ToolTip TTIP = new ToolTip();
            tb.BackColor = Color.LightGreen;
            TTIP.SetToolTip(tb, "");
            errorProvider1.SetError(tb, "");
            return true;
        }

        /// <summary>
        /// Marca la casilla en verde en un masked text box
        /// </summary>
        /// <param name="tb"></param>
        /// <returns></returns>
        private bool MarcarCampoOk(MaskedTextBox tb)
        {
            ToolTip TTIP = new ToolTip();
            tb.BackColor = Color.LightGreen;
            TTIP.SetToolTip(tb, "");
            errorProvider1.SetError(tb, "");
            return true;
        }

        /// <summary>
        /// Marca la casilla en verde en un DateTimePicker
        /// </summary>
        /// <param name="dtp"></param>
        /// <returns></returns>
        private bool MarcarCampoOk(DateTimePicker dtp)
        {
            ToolTip TTIP = new ToolTip();
            TTIP.SetToolTip(dtp, "");            
            errorProvider1.SetError(dtp, "");
            dtp.ShowCheckBox = true;
            return true;
        }
        #endregion

        /// <summary>
        /// función para establecer inicialmente el foco en un campo, en este caso el textbox Nombre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EstablecerFocoInicial(object sender, EventArgs e)
        {
            tbNombre.Focus();
        }        
    }  
}
