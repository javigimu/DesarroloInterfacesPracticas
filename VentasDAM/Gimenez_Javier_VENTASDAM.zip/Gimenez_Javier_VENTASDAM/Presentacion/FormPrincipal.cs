﻿using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    /// <summary>
    /// <autor>Javier Giménez</autor>
    /// </summary>
    public partial class FormPrincipal : Form
    {
        private int empleadoSeleccionadoId;
        private string? empleadoSeleccionadoNombre;
        private byte[]? empleadoSeleccionadoFoto;

        public FormPrincipal()
        {
            InitializeComponent();
        }

        public void FormPrincipal_Load(object sender, EventArgs e)
        {
            FormSeleccionUsuario fsu = new FormSeleccionUsuario();
            fsu.Owner = this;
            this.Hide();
            fsu.ShowDialog();
  
            empleadoSeleccionadoId = fsu.EmpleadoSeleccionadoId;
            using (Gestion g = new Gestion())
            {
                empleadoSeleccionadoNombre = g.ObtenerNombreEmpleado(empleadoSeleccionadoId);
                empleadoSeleccionadoFoto = g.ObtenerFotoEmpleado(empleadoSeleccionadoId);
                tsNombreEmpleado.Text = empleadoSeleccionadoNombre;

                Image? fotoEmpleado = byteArrayToImage(empleadoSeleccionadoFoto);
                tsFotoEmpleado.Image = fotoEmpleado;
                
                lbNombreEmpleado.Text = empleadoSeleccionadoNombre;
                pbFotoEmpleado.Image = fotoEmpleado;

                
            }
        }

        public Image? byteArrayToImage(byte[]? imagenEnBytes)
        {
            if (imagenEnBytes != null)
            {
                System.Drawing.ImageConverter converter = new System.Drawing.ImageConverter();
                Image? img = (Image?)converter.ConvertFrom(imagenEnBytes);
                return img;
            }
            return null;
        }

        private void LanzarFormEmpleadosInsertar(object sender, EventArgs e)
        {
            FormEmpleados formEmpleados = new FormEmpleados('i');
            formEmpleados.Owner = this;
            this.Hide();
            formEmpleados.Show();            
        }

        private void LanzarFormEmpleadosModificar(object sender, EventArgs e)
        {
            FormEmpleados formEmpleados = new FormEmpleados('m');
            formEmpleados.Owner = this;
            this.Hide();
            formEmpleados.Show();
        }

    }
}
