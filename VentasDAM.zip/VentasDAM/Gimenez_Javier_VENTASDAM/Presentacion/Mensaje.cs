﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class Mensaje
    {
        public static void MostrarProcesoFinalizadoCorrectamente()
        {
            MessageBox.Show("Proceso finalizado correctamente");
        }

    }
}
